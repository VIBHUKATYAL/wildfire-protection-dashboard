// vue.config.js
module.exports = {
  runtimeCompiler: true,
};
